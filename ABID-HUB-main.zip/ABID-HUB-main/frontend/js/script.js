// Small JS for demo interactions
document.addEventListener('DOMContentLoaded', function(){
  console.log('Online IT Academy demo loaded');
});
